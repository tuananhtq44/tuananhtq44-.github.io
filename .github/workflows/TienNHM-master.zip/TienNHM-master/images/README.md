# Hướng dẫn dùng Markdown

**MỤC LỤC**

1. [Định dạng](https://github.com/TienNHM/TienNHM/blob/master/images/README.md#%C4%91%E1%BB%8Bnh-d%E1%BA%A1ng)
2. [Code](https://github.com/TienNHM/TienNHM/blob/master/images/README.md#code)

### Định dạng

**In đậm**

_In nghiêng_

_**Gạch chân**_

### Code

```js
alert("Hello");
console.log("ping");
```

Hi there, I am `Nguyen Huynh Minh Tien`.

### Trích dẫn

> Đây là trích dẫn.

### Đánh thứ tự

- Hello
  - Hello
  - Hi
  - Chào
- Hi
- Chào

1. Hello
2. Hi
3. HHH

### Summary

<details>
  <summary>Mở rộng</summary>
  
    [![Meme](https://thosuaxe.info/wp-content/uploads/2021/03/M%E1%BB%99t-trong-nh%E1%BB%AFng-Memes-kinh-%C4%91i%E1%BB%83n-nh%E1%BA%A5t-tr%C3%AAn-internet.jpg)](https://www.facebook.com/)
  
  <p align="center">
    <img src="https://thosuaxe.info/wp-content/uploads/2021/03/M%E1%BB%99t-trong-nh%E1%BB%AFng-Memes-kinh-%C4%91i%E1%BB%83n-nh%E1%BA%A5t-tr%C3%AAn-internet.jpg" 
         width="100px"/>
  </p>
  
  <details>
  <summary>Mở rộng</summary>
  
  [![Meme](https://thosuaxe.info/wp-content/uploads/2021/03/M%E1%BB%99t-trong-nh%E1%BB%AFng-Memes-kinh-%C4%91i%E1%BB%83n-nh%E1%BA%A5t-tr%C3%AAn-internet.jpg)](https://www.facebook.com/)

<p align="center">
  <img src="https://thosuaxe.info/wp-content/uploads/2021/03/M%E1%BB%99t-trong-nh%E1%BB%AFng-Memes-kinh-%C4%91i%E1%BB%83n-nh%E1%BA%A5t-tr%C3%AAn-internet.jpg" 
       width="100px"/>
</p>
</details>
  
</details>


:100: 👽🉑🌟

### Bảng

| STT | Họ tên | Giới tính |
| :---: | --- | ---: |
| 1 | NVA | Nam |
| 2 | NVB | Nữ |

